Information:

This example has basic functionality and reads data stored in a database using Ruby on Rails.

NOTE: For this example to work you have to run it in a web server context with Ruby on Rails configured.

This example requires:

* RoR
* ExtGantt4.x

Preparations:

* Copy gnt-all.js to /vendor/assets/javascripts
* Copy sch-gantt-triton-all.css to /vendor/assets/stylesheets