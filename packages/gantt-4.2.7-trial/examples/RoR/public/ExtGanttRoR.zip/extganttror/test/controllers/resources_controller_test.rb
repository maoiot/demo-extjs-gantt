require 'test_helper'

class ResourcesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
