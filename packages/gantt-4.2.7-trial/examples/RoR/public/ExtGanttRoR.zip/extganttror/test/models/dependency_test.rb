require 'test_helper'

class DependencyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
